<?php

namespace Drupal\rules\Exception;

/**
 * An Exception that is thrown if a value is not a valid key.
 */
class OutOfBoundsException extends RulesException {

}
