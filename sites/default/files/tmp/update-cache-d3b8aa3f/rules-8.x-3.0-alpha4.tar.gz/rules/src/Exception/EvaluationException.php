<?php

namespace Drupal\rules\Exception;

/**
 * An exception that is thrown during evaluation.
 */
class EvaluationException extends RulesException {

}
