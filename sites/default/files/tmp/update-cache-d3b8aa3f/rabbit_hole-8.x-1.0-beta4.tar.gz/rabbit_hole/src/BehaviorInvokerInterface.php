<?php

namespace Drupal\rabbit_hole;

/**
 * Interface BehaviorInvokerInterface.
 *
 * @package Drupal\rabbit_hole
 */
interface BehaviorInvokerInterface {


}
